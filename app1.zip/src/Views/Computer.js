import React, { Component } from "react";

export class Biology extends Component {
  render() {
    return <div>Computer View</div>;
  }
}

export default Biology;
