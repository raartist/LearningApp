import React, { Component } from "react";

export class Biology extends Component {
  render() {
    return <div>Maths View</div>;
  }
}

export default Biology;
