import React, { Component } from "react";

export class Biology extends Component {
  render() {
    return <div>Yoga View</div>;
  }
}

export default Biology;
