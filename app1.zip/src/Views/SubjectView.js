import React, { Component } from "react";

export class SubjectView extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Data: this.props,
    };
  }

  render() {
    return <div></div>;
  }
}

export default SubjectView;
