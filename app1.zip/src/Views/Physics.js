import React, { Component } from "react";

export class Physics extends Component {
  componentDidMount() {
    console.log("physics firedd...");
  }
  render() {
    return <div>Physics View</div>;
  }
}

export default Physics;
